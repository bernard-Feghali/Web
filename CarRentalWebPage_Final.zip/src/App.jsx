
import React from "react";
import CarRental from "./pages/CarRental";
import "./index.css";

export default function App() {
  return (
    <div>
      <CarRental />
    </div>
  );
}
